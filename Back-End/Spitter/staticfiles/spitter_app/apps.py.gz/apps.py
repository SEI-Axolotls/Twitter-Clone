from django.apps import AppConfig


class SpitterAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'spitter_app'
